export interface IDailyForecast {
    day: string;
    high_temp: number;
    low_temp: number;
    month_day: string;
    description: string;
}